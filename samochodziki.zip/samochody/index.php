<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Samochody</title>
</head>
<body>
<table width="1000" align="center" border="1" bordercolor="#d5d5d5"  cellpadding="0" cellspacing="0">
        <tr>
        <?php
            ini_set("display_errors", 0);
            require_once "dbconnect.php";
            $pol = mysqli_connect($host, $user, $password);
            mysqli_query($pol, "SET CHARSET utf8");
            mysqli_query($pol, "SET NAMES 'utf8' COLLATE 'utf8_polish_ci'");
            mysqli_select_db($pol, $database);

            $zapytanietxt = file_get_contents("zapytanie.txt");

            $rezultat = mysqli_query($pol, $zapytanietxt);
            $ile = mysqli_num_rows($rezultat);

            echo "znaleziono: ".$ile;
if ($ile>=1) 
{
    echo<<<END
    <td width="50" algin="center" bgcolor="e5e5e5">idauta</td>
    <td width="100" algin="center" bgcolor="e5e5e5">marka</td>
    <td width="100" algin="center" bgcolor="e5e5e5">model</td>
    <td width="100" algin="center" bgcolor="e5e5e5">przebieg</td>
    <td width="50" algin="center" bgcolor="e5e5e5">rocznik</td>
    <td width="100" algin="center" bgcolor="e5e5e5">kolor</td>
    <td width="100" algin="center" bgcolor="e5e5e5">ubezpieczenie</td>
    <td width="100" algin="center" bgcolor="e5e5e5">idklienta</td>
    <td width="50" algin="center" bgcolor="e5e5e5">imie</td>
    <td width="100" algin="center" bgcolor="e5e5e5">nazwisko</td>
    <td width="100" algin="center" bgcolor="e5e5e5">dowod</td>
    <td width="100" algin="center" bgcolor="e5e5e5">adres</td>
    <td width="100" algin="center" bgcolor="e5e5e5">miasto</td>
    <td width="50" algin="center" bgcolor="e5e5e5">plec</td>
    <td width="100" algin="center" bgcolor="e5e5e5">idwyp</td>
    <td width="100" algin="center" bgcolor="e5e5e5">datawyp</td>
    <td width="50" algin="center" bgcolor="e5e5e5">datazwrotu</td>
    <td width="100" algin="center" bgcolor="e5e5e5">naleznosc</td>
    <tr></tr>
    END;

}

for ($i = 1; $i <= $ile; $i++)
{

    $row = mysqli_fetch_assoc($rezultat);
    $a1 = $row['idauta'];
    $a2 = $row['marka'];
    $a3 = $row['model'];
    $a4 = $row['przebieg'];
    $a5 = $row['rocznik'];
    $a6 = $row['kolor'];
    $a7 = $row['ubezpieczenie'];
    $a8 = $row['idklienta'];
    $a9 = $row['imie'];
    $a10 = $row['nazwisko'];
    $a11 = $row['dowod'];
    $a12 = $row['adres'];
    $a13 = $row['miasto'];
    $a14 = $row['plec'];
    $a15 = $row['idwyp'];
    $a16 = $row['datawyp'];
    $a17 = $row['datazwrotu'];
    $a18 = $row['nalezonsc'];

    echo<<<END
<td width="50" align="center">$a1</td>
<td width="100" align="center">$a2</td>
<td width="100" align="center">$a3</td>
<td width="100" align="center">$a4</td>
<td width="100" align="center">$a5</td>
<td width="100" align="center">$a6</td>
<td width="100" align="center">$a7</td>
<td width="100" align="center">$a8</td>
<td width="100" align="center">$a9</td>
<td width="50" align="center">$a10</td>
<td width="100" align="center">$a11</td>
<td width="100" align="center">$a12</td>
<td width="100" align="center">$a13</td>
<td width="100" align="center">$a14</td>
<td width="100" align="center">$a15</td>
<td width="100" align="center">$a16</td>
<td width="100" align="center">$a17</td>
<td width="100" align="center">$a18</td>
</tr><tr>
END;
}
?>

</tr></table> 
</body>
</html>